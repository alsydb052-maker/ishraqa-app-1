package com.ishraqa.app

import android.content.Context
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

object FontHelper {
    private var mediumFont: Typeface? = null
    private var boldFont: Typeface? = null
    private var initialized = false

    private fun init(context: Context) {
        if (initialized) return
        initialized = true
        mediumFont = try {
            Typeface.createFromAsset(context.assets, "fonts/tajawal_medium.ttf")
        } catch (_: Exception) {
            null
        }
        boldFont = try {
            Typeface.createFromAsset(context.assets, "fonts/tajawal_bold.ttf")
        } catch (_: Exception) {
            mediumFont
        }
    }

    fun getMedium(context: Context): Typeface {
        init(context)
        return mediumFont ?: Typeface.DEFAULT
    }

    fun getBold(context: Context): Typeface {
        init(context)
        return boldFont ?: Typeface.DEFAULT_BOLD
    }

    fun applyToHierarchy(context: Context, root: View) {
        init(context)
        if (mediumFont == null && boldFont == null) return
        if (root is ViewGroup) {
            for (i in 0 until root.childCount) {
                applyToHierarchy(context, root.getChildAt(i))
            }
        } else if (root is TextView) {
            val isBold = root.typeface?.isBold == true
            root.typeface = if (isBold) getBold(context) else getMedium(context)
        }
    }
}
