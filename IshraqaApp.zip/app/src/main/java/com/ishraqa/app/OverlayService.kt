package com.ishraqa.app

import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "com.ishraqa.app.ACTION_START"
        const val ACTION_STOP = "com.ishraqa.app.ACTION_STOP"
        const val ACTION_SHOW_NOW = "com.ishraqa.app.ACTION_SHOW_NOW"
        const val ACTION_RELOAD = "com.ishraqa.app.ACTION_RELOAD"

        private const val CHANNEL_ID = "ishraqa_overlay_channel"
        private const val NOTIFICATION_ID = 1001
    }

    private lateinit var prefs: PrefsManager
    private lateinit var windowManager: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var overlayView: View? = null
    private var isDismissing = false
    private var nextScheduledTime = 0L
    private var pendingShowOnUnlock = false

    private val checkRunnable = object : Runnable {
        override fun run() {
            if (!prefs.isServiceEnabled()) return
            val now = SystemClock.elapsedRealtime()
            if (now >= nextScheduledTime) {
                if (isScreenActiveAndUnlocked()) {
                    if (overlayView == null) {
                        showOverlayBanner()
                    }
                } else {
                    pendingShowOnUnlock = true
                }
            } else {
                val remaining = (nextScheduledTime - now).coerceAtMost(30_000L)
                handler.postDelayed(this, remaining)
            }
        }
    }

    private val autoDismissRunnable = Runnable {
        dismissOverlay(directionY = -1f, directionX = 0f)
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_USER_PRESENT) {
                if (!prefs.isServiceEnabled()) return
                val now = SystemClock.elapsedRealtime()
                if ((pendingShowOnUnlock || now >= nextScheduledTime) && overlayView == null) {
                    pendingShowOnUnlock = false
                    handler.postDelayed({
                        if (prefs.isServiceEnabled() && overlayView == null && isScreenActiveAndUnlocked()) {
                            showOverlayBanner()
                        }
                    }, 1200L)
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = PrefsManager(this)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()

        val filter = IntentFilter(Intent.ACTION_USER_PRESENT)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(screenReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenReceiver, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundSafely()

        when (intent?.action) {
            ACTION_STOP -> {
                prefs.setServiceEnabled(false)
                cancelSchedules()
                removeOverlayImmediately()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }

            ACTION_SHOW_NOW -> {
                showOverlayBanner()
                if (prefs.isServiceEnabled()) {
                    scheduleNext()
                }
                return if (prefs.isServiceEnabled()) START_STICKY else START_NOT_STICKY
            }

            ACTION_RELOAD -> {
                if (prefs.isServiceEnabled()) {
                    scheduleNext()
                }
                return START_STICKY
            }

            else -> {
                if (prefs.isServiceEnabled()) {
                    scheduleNext()
                    return START_STICKY
                } else {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                    return START_NOT_STICKY
                }
            }
        }
    }

    private fun startForegroundSafely() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "خدمة إشراقة",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعار صامت لإبقاء إشراقة تعمل في الخلفية"
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val showNowIntent = Intent(this, OverlayService::class.java).apply {
            action = ACTION_SHOW_NOW
        }
        val showNowPending = PendingIntent.getService(
            this, 1, showNowIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, OverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this, 2, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val minutes = prefs.getIntervalMinutes()
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_sun_sparkle)
            .setContentTitle("إشراقة تعمل في الخلفية")
            .setContentText("تظهر جملك كل $minutes دقيقة")
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openPending)
            .addAction(0, "عرض الآن", showNowPending)
            .addAction(0, "إيقاف", stopPending)
            .build()
    }

    private fun scheduleNext() {
        handler.removeCallbacks(checkRunnable)
        pendingShowOnUnlock = false
        val intervalMs = prefs.getIntervalMinutes() * 60_000L
        nextScheduledTime = SystemClock.elapsedRealtime() + intervalMs
        val initialDelay = intervalMs.coerceAtMost(30_000L)
        handler.postDelayed(checkRunnable, initialDelay)
    }

    private fun cancelSchedules() {
        handler.removeCallbacks(checkRunnable)
        handler.removeCallbacks(autoDismissRunnable)
        pendingShowOnUnlock = false
    }

    private fun isScreenActiveAndUnlocked(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        return pm.isInteractive && !km.isKeyguardLocked
    }

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun showOverlayBanner() {
        if (!Settings.canDrawOverlays(this)) return
        val sentence = prefs.getNextSentence() ?: return

        removeOverlayImmediately()
        isDismissing = false

        val view = LayoutInflater.from(this).inflate(R.layout.overlay_banner, null)
        FontHelper.applyToHierarchy(this, view)

        val tvSentence = view.findViewById<TextView>(R.id.tvBannerSentence)
        val bannerCard = view.findViewById<View>(R.id.bannerCard)
        tvSentence.text = sentence

        val topMargin = getStatusBarHeight() + dpToPx(8)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = topMargin
        }

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var startRawX = 0f
        var startRawY = 0f
        var moved = false

        bannerCard.setOnTouchListener { v, event ->
            if (isDismissing) return@setOnTouchListener true
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startRawX = event.rawX
                    startRawY = event.rawY
                    moved = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - startRawX
                    val dy = event.rawY - startRawY
                    if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
                        moved = true
                    }
                    if (abs(dx) > abs(dy)) {
                        v.translationX = dx
                        v.translationY = 0f
                        val width = v.width.coerceAtLeast(1)
                        v.alpha = (1f - abs(dx) / (width * 0.9f)).coerceIn(0.25f, 1f)
                    } else if (dy < 0) {
                        v.translationY = dy
                        v.translationX = 0f
                        v.alpha = (1f - abs(dy) / dpToPx(140).toFloat()).coerceIn(0.25f, 1f)
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val dx = event.rawX - startRawX
                    val dy = event.rawY - startRawY
                    when {
                        !moved -> {
                            dismissOverlay(directionY = -1f, directionX = 0f)
                        }
                        dy < -dpToPx(40) -> {
                            dismissOverlay(directionY = -1f, directionX = 0f)
                        }
                        abs(dx) > dpToPx(75) -> {
                            dismissOverlay(directionY = 0f, directionX = if (dx > 0) 1f else -1f)
                        }
                        else -> {
                            v.animate()
                                .translationX(0f)
                                .translationY(0f)
                                .alpha(1f)
                                .setDuration(180)
                                .start()
                        }
                    }
                    true
                }

                else -> false
            }
        }

        try {
            windowManager.addView(view, params)
            overlayView = view

            bannerCard.translationY = -dpToPx(120).toFloat()
            bannerCard.alpha = 0f
            bannerCard.animate()
                .translationY(0f)
                .alpha(1f)
                .setDuration(320)
                .setInterpolator(DecelerateInterpolator())
                .start()

            handler.removeCallbacks(autoDismissRunnable)
            if (prefs.isAutoDismissEnabled()) {
                val delayMs = prefs.getDurationSeconds() * 1000L
                handler.postDelayed(autoDismissRunnable, delayMs)
            }
        } catch (_: Exception) {
            overlayView = null
        }
    }

    private fun dismissOverlay(directionY: Float, directionX: Float) {
        val currentView = overlayView ?: return
        if (isDismissing) return
        isDismissing = true
        handler.removeCallbacks(autoDismissRunnable)

        val card = currentView.findViewById<View>(R.id.bannerCard)
        val targetX = if (directionX != 0f) directionX * dpToPx(360) else card.translationX
        val targetY = if (directionY != 0f) directionY * dpToPx(150) else card.translationY

        card.animate()
            .translationX(targetX)
            .translationY(targetY)
            .alpha(0f)
            .setDuration(220)
            .withEndAction {
                removeOverlayImmediately()
                onOverlayClosed()
            }
            .start()
    }

    private fun removeOverlayImmediately() {
        handler.removeCallbacks(autoDismissRunnable)
        overlayView?.let { v ->
            try {
                windowManager.removeView(v)
            } catch (_: Exception) {
            }
        }
        overlayView = null
        isDismissing = false
    }

    private fun onOverlayClosed() {
        if (prefs.isServiceEnabled()) {
            scheduleNext()
        } else {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun getStatusBarHeight(): Int {
        val resId = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (resId > 0) resources.getDimensionPixelSize(resId) else dpToPx(28)
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }

    override fun onDestroy() {
        cancelSchedules()
        removeOverlayImmediately()
        try {
            unregisterReceiver(screenReceiver)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
