package com.ishraqa.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsManager
    private lateinit var adapter: SentenceAdapter
    private var sentences = mutableListOf<String>()

    private lateinit var viewStatusDot: View
    private lateinit var tvStatusText: TextView
    private lateinit var btnToggleService: TextView
    private lateinit var btnPreviewNow: TextView
    private lateinit var btnBatteryOptimize: TextView
    private lateinit var etIntervalMinutes: EditText
    private lateinit var rbDurationManual: RadioButton
    private lateinit var rbDurationAuto: RadioButton
    private lateinit var etDurationSeconds: EditText
    private lateinit var btnOrderSequential: TextView
    private lateinit var btnOrderRandom: TextView
    private lateinit var btnAddSentence: TextView
    private lateinit var tvEmptyState: TextView
    private lateinit var rvSentences: RecyclerView

    private lateinit var intervalChips: Map<Int, TextView>
    private var suppressWatchers = false

    private val notifPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        proceedStartOrPreview()
    }

    private var pendingAction: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = PrefsManager(this)
        bindViews()
        FontHelper.applyToHierarchy(this, findViewById(android.R.id.content))
        setupSentencesList()
        setupListeners()
        loadUiState()
    }

    override fun onResume() {
        super.onResume()
        updateServiceUi()
        updateBatteryButtonVisibility()
    }

    private fun bindViews() {
        viewStatusDot = findViewById(R.id.viewStatusDot)
        tvStatusText = findViewById(R.id.tvStatusText)
        btnToggleService = findViewById(R.id.btnToggleService)
        btnPreviewNow = findViewById(R.id.btnPreviewNow)
        btnBatteryOptimize = findViewById(R.id.btnBatteryOptimize)
        etIntervalMinutes = findViewById(R.id.etIntervalMinutes)
        rbDurationManual = findViewById(R.id.rbDurationManual)
        rbDurationAuto = findViewById(R.id.rbDurationAuto)
        etDurationSeconds = findViewById(R.id.etDurationSeconds)
        btnOrderSequential = findViewById(R.id.btnOrderSequential)
        btnOrderRandom = findViewById(R.id.btnOrderRandom)
        btnAddSentence = findViewById(R.id.btnAddSentence)
        tvEmptyState = findViewById(R.id.tvEmptyState)
        rvSentences = findViewById(R.id.rvSentences)

        intervalChips = mapOf(
            5 to findViewById(R.id.chipMin5),
            15 to findViewById(R.id.chipMin15),
            30 to findViewById(R.id.chipMin30),
            60 to findViewById(R.id.chipMin60)
        )
    }

    private fun setupSentencesList() {
        sentences = prefs.getSentences()
        adapter = SentenceAdapter(
            items = sentences,
            onEdit = { position, currentText ->
                showSentenceDialog(editIndex = position, existingText = currentText)
            },
            onDelete = { position ->
                AlertDialog.Builder(this)
                    .setTitle("حذف الجملة")
                    .setMessage("هل تريد حذف هذه الجملة من القائمة؟")
                    .setPositiveButton("حذف") { _, _ ->
                        sentences.removeAt(position)
                        prefs.saveSentences(sentences)
                        adapter.notifyItemRemoved(position)
                        adapter.notifyItemRangeChanged(position, sentences.size)
                        updateEmptyState()
                    }
                    .setNegativeButton("إلغاء", null)
                    .show()
            }
        )
        rvSentences.layoutManager = LinearLayoutManager(this)
        rvSentences.adapter = adapter
        updateEmptyState()
    }

    private fun setupListeners() {
        btnToggleService.setOnClickListener {
            if (prefs.isServiceEnabled()) {
                stopOverlayService()
            } else {
                if (sentences.isEmpty()) {
                    Toast.makeText(this, "أضف جملة واحدة على الأقل أولاً", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                pendingAction = OverlayService.ACTION_START
                checkPermissionsAndRun()
            }
        }

        btnPreviewNow.setOnClickListener {
            if (sentences.isEmpty()) {
                Toast.makeText(this, "أضف جملة واحدة على الأقل أولاً", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            pendingAction = OverlayService.ACTION_SHOW_NOW
            checkPermissionsAndRun()
        }

        btnBatteryOptimize.setOnClickListener {
            requestBatteryOptimizationExemption()
        }

        intervalChips.forEach { (minutes, chipView) ->
            chipView.setOnClickListener {
                suppressWatchers = true
                etIntervalMinutes.setText(minutes.toString())
                suppressWatchers = false
                prefs.setIntervalMinutes(minutes)
                updateIntervalChips(minutes)
                notifyServiceReload()
            }
        }

        etIntervalMinutes.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (suppressWatchers) return
                val minutes = s?.toString()?.toIntOrNull()
                if (minutes != null && minutes >= 1) {
                    prefs.setIntervalMinutes(minutes)
                    updateIntervalChips(minutes)
                    notifyServiceReload()
                }
            }
        })

        rbDurationManual.setOnClickListener {
            setDurationMode(autoDismiss = false)
        }

        rbDurationAuto.setOnClickListener {
            setDurationMode(autoDismiss = true)
        }

        etDurationSeconds.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (suppressWatchers) return
                val sec = s?.toString()?.toIntOrNull()
                if (sec != null && sec >= 2) {
                    prefs.setDurationSeconds(sec)
                }
            }
        })

        btnOrderSequential.setOnClickListener {
            prefs.setRandomOrder(false)
            updateOrderUi(false)
        }

        btnOrderRandom.setOnClickListener {
            prefs.setRandomOrder(true)
            updateOrderUi(true)
        }

        btnAddSentence.setOnClickListener {
            showSentenceDialog(editIndex = null, existingText = "")
        }
    }

    private fun setDurationMode(autoDismiss: Boolean) {
        prefs.setAutoDismissEnabled(autoDismiss)
        rbDurationManual.isChecked = !autoDismiss
        rbDurationAuto.isChecked = autoDismiss
        etDurationSeconds.isEnabled = autoDismiss
        etDurationSeconds.alpha = if (autoDismiss) 1f else 0.45f
    }

    private fun loadUiState() {
        suppressWatchers = true
        val minutes = prefs.getIntervalMinutes()
        etIntervalMinutes.setText(minutes.toString())
        updateIntervalChips(minutes)

        val autoDismiss = prefs.isAutoDismissEnabled()
        rbDurationManual.isChecked = !autoDismiss
        rbDurationAuto.isChecked = autoDismiss
        etDurationSeconds.setText(prefs.getDurationSeconds().toString())
        etDurationSeconds.isEnabled = autoDismiss
        etDurationSeconds.alpha = if (autoDismiss) 1f else 0.45f

        updateOrderUi(prefs.isRandomOrder())
        updateServiceUi()
        updateBatteryButtonVisibility()
        suppressWatchers = false
    }

    private fun updateIntervalChips(selectedMinutes: Int) {
        intervalChips.forEach { (min, chip) ->
            val selected = (min == selectedMinutes)
            chip.setBackgroundResource(
                if (selected) R.drawable.bg_chip_selected else R.drawable.bg_chip_unselected
            )
            chip.setTextColor(
                ContextCompat.getColor(
                    this,
                    if (selected) R.color.white else R.color.text_primary
                )
            )
        }
    }

    private fun updateOrderUi(isRandom: Boolean) {
        btnOrderSequential.setBackgroundResource(
            if (!isRandom) R.drawable.bg_chip_selected else R.drawable.bg_chip_unselected
        )
        btnOrderSequential.setTextColor(
            ContextCompat.getColor(this, if (!isRandom) R.color.white else R.color.text_primary)
        )

        btnOrderRandom.setBackgroundResource(
            if (isRandom) R.drawable.bg_chip_selected else R.drawable.bg_chip_unselected
        )
        btnOrderRandom.setTextColor(
            ContextCompat.getColor(this, if (isRandom) R.color.white else R.color.text_primary)
        )
    }

    private fun updateServiceUi() {
        val enabled = prefs.isServiceEnabled()
        if (enabled) {
            viewStatusDot.setBackgroundResource(R.drawable.bg_dot_active)
            tvStatusText.text = getString(R.string.status_running)
            btnToggleService.text = getString(R.string.btn_stop)
            btnToggleService.setBackgroundResource(R.drawable.bg_btn_stop)
        } else {
            viewStatusDot.setBackgroundResource(R.drawable.bg_dot_inactive)
            tvStatusText.text = getString(R.string.status_stopped)
            btnToggleService.text = getString(R.string.btn_start)
            btnToggleService.setBackgroundResource(R.drawable.bg_btn_primary)
        }
    }

    private fun updateEmptyState() {
        tvEmptyState.visibility = if (sentences.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showSentenceDialog(editIndex: Int?, existingText: String) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_sentence, null)
        FontHelper.applyToHierarchy(this, dialogView)
        val input = dialogView.findViewById<EditText>(R.id.etSentenceInput)
        input.setText(existingText)
        input.setSelection(existingText.length)

        AlertDialog.Builder(this)
            .setTitle(if (editIndex == null) "إضافة جملة جديدة" else "تعديل الجملة")
            .setView(dialogView)
            .setPositiveButton("حفظ") { _, _ ->
                val text = input.text.toString().trim()
                if (text.isEmpty()) {
                    Toast.makeText(this, "اكتب الجملة أولاً", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (editIndex == null) {
                    sentences.add(text)
                    adapter.notifyItemInserted(sentences.size - 1)
                } else {
                    sentences[editIndex] = text
                    adapter.notifyItemChanged(editIndex)
                }
                prefs.saveSentences(sentences)
                updateEmptyState()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun checkPermissionsAndRun() {
        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("صلاحية الظهور فوق التطبيقات")
                .setMessage("لكي تظهر جملك أعلى الشاشة فوق التطبيقات الأخرى، فعّل خيار «الظهور فوق التطبيقات الأخرى» لتطبيق إشراقة ثم ارجع هنا.")
                .setPositiveButton("فتح الإعدادات") { _, _ ->
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                }
                .setNegativeButton("إلغاء", null)
                .show()
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }

        proceedStartOrPreview()
    }

    private fun proceedStartOrPreview() {
        val action = pendingAction ?: return
        pendingAction = null

        if (action == OverlayService.ACTION_START) {
            prefs.setServiceEnabled(true)
            updateServiceUi()
            val intent = Intent(this, OverlayService::class.java).apply {
                this.action = OverlayService.ACTION_START
            }
            ContextCompat.startForegroundService(this, intent)
            Toast.makeText(
                this,
                "تم تشغيل إشراقة! ستظهر كل ${prefs.getIntervalMinutes()} دقيقة",
                Toast.LENGTH_SHORT
            ).show()
        } else if (action == OverlayService.ACTION_SHOW_NOW) {
            val intent = Intent(this, OverlayService::class.java).apply {
                this.action = OverlayService.ACTION_SHOW_NOW
            }
            ContextCompat.startForegroundService(this, intent)
        }
    }

    private fun stopOverlayService() {
        prefs.setServiceEnabled(false)
        updateServiceUi()
        stopService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "تم إيقاف إشراقة مؤقتاً", Toast.LENGTH_SHORT).show()
    }

    private fun notifyServiceReload() {
        if (prefs.isServiceEnabled()) {
            val intent = Intent(this, OverlayService::class.java).apply {
                action = OverlayService.ACTION_RELOAD
            }
            ContextCompat.startForegroundService(this, intent)
        }
    }

    private fun updateBatteryButtonVisibility() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val ignoring = pm.isIgnoringBatteryOptimizations(packageName)
        btnBatteryOptimize.visibility = if (ignoring) View.GONE else View.VISIBLE
    }

    private fun requestBatteryOptimizationExemption() {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (_: Exception) {
            }
        }
    }
}
