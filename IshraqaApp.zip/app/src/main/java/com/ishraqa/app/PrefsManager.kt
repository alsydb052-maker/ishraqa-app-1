package com.ishraqa.app

import android.content.Context
import org.json.JSONArray
import kotlin.random.Random

class PrefsManager(context: Context) {

    private val prefs = context.getSharedPreferences("ishraqa_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_SENTENCES = "sentences_json"
        private const val KEY_INITIALIZED = "defaults_initialized"
        private const val KEY_INTERVAL_MIN = "interval_minutes"
        private const val KEY_AUTO_DISMISS = "auto_dismiss_enabled"
        private const val KEY_DURATION_SEC = "duration_seconds"
        private const val KEY_RANDOM_ORDER = "random_order"
        private const val KEY_SERVICE_ENABLED = "service_enabled"
        private const val KEY_LAST_INDEX = "last_sentence_index"
    }

    init {
        if (!prefs.getBoolean(KEY_INITIALIZED, false)) {
            val defaults = listOf(
                "تنفّس بهدوء.. الخير قادم بإذن الله",
                "خطوة صغيرة كل يوم تصنع فرقاً كبيراً",
                "اذكر الله يطمئن قلبك ويهدأ بالك"
            )
            saveSentences(defaults)
            prefs.edit().putBoolean(KEY_INITIALIZED, true).apply()
        }
    }

    fun getSentences(): MutableList<String> {
        val raw = prefs.getString(KEY_SENTENCES, "[]") ?: "[]"
        val list = mutableListOf<String>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val item = arr.optString(i).trim()
                if (item.isNotEmpty()) {
                    list.add(item)
                }
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun saveSentences(sentences: List<String>) {
        val arr = JSONArray()
        sentences.forEach { text ->
            val trimmed = text.trim()
            if (trimmed.isNotEmpty()) {
                arr.put(trimmed)
            }
        }
        prefs.edit().putString(KEY_SENTENCES, arr.toString()).apply()
    }

    fun getIntervalMinutes(): Int {
        return prefs.getInt(KEY_INTERVAL_MIN, 15).coerceAtLeast(1)
    }

    fun setIntervalMinutes(minutes: Int) {
        prefs.edit().putInt(KEY_INTERVAL_MIN, minutes.coerceAtLeast(1)).apply()
    }

    fun isAutoDismissEnabled(): Boolean {
        return prefs.getBoolean(KEY_AUTO_DISMISS, false)
    }

    fun setAutoDismissEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO_DISMISS, enabled).apply()
    }

    fun getDurationSeconds(): Int {
        return prefs.getInt(KEY_DURATION_SEC, 10).coerceAtLeast(2)
    }

    fun setDurationSeconds(seconds: Int) {
        prefs.edit().putInt(KEY_DURATION_SEC, seconds.coerceAtLeast(2)).apply()
    }

    fun isRandomOrder(): Boolean {
        return prefs.getBoolean(KEY_RANDOM_ORDER, false)
    }

    fun setRandomOrder(random: Boolean) {
        prefs.edit().putBoolean(KEY_RANDOM_ORDER, random).apply()
    }

    fun isServiceEnabled(): Boolean {
        return prefs.getBoolean(KEY_SERVICE_ENABLED, false)
    }

    fun setServiceEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SERVICE_ENABLED, enabled).apply()
    }

    fun getNextSentence(): String? {
        val list = getSentences()
        if (list.isEmpty()) return null
        if (list.size == 1) {
            prefs.edit().putInt(KEY_LAST_INDEX, 0).apply()
            return list[0]
        }

        val lastIndex = prefs.getInt(KEY_LAST_INDEX, -1)
        val nextIndex = if (isRandomOrder()) {
            var pick = Random.nextInt(list.size)
            if (pick == lastIndex) {
                pick = (pick + 1) % list.size
            }
            pick
        } else {
            (lastIndex + 1) % list.size
        }

        prefs.edit().putInt(KEY_LAST_INDEX, nextIndex).apply()
        return list[nextIndex]
    }
}
