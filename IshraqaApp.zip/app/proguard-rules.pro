# Keep default Android rules
